const {chromium}=require('playwright');(async()=>{const b=await chromium.launch({proxy:{server:process.env.HTTPS_PROXY},args:['--ignore-certificate-errors']});const p=await b.newPage({viewport:{width:1400,height:950}});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/user/claude/tools/mapas/editor.html');await p.waitForTimeout(600);
await p.click('#tabRef');await p.selectOption('#fJuego','FE4');await p.waitForTimeout(200);
console.log((await p.$$('#tRef tr')).length,'FE7',(await p.$$('[data-abrir]')).length,'con mapa');
await p.fill('#fTexto','spirit');await p.waitForTimeout(200);await p.click('[data-abrir]');await p.waitForTimeout(2500);
console.log(await p.$eval('#nombre',e=>e.value), await p.$eval('#msgImg',e=>e.textContent));
await (await p.$('#cv')).screenshot({path:'/tmp/claude-0/-home-user-claude/239a793c-ff8c-5333-9eea-86ef9c21d83a/scratchpad/s5.png'});
console.log('errores',errs);await b.close();})();
