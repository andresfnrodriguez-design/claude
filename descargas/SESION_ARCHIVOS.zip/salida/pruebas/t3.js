const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1400,height:950}});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/user/claude/tools/mapas/editor.html');await p.waitForTimeout(600);
await p.click('#tabRef');console.log((await p.$$('#tRef tr')).length,'filas',(await p.$$('[data-abrir]')).length,'con mapa');
await p.fill('#fTexto','Scorched');await p.waitForTimeout(200);await p.click('[data-abrir]');await p.waitForTimeout(400);
console.log(await p.$eval('#nombre',e=>e.value));console.log(await p.$eval('#chequeo',e=>e.innerText.replace(/\n/g,' | ')));
await p.screenshot({path:'/tmp/claude-0/-home-user-claude/239a793c-ff8c-5333-9eea-86ef9c21d83a/scratchpad/s3.png'});
console.log('errores',errs);await b.close();})();
