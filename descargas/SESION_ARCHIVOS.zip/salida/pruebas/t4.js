const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const p=await b.newPage({viewport:{width:1400,height:950}});
const errs=[];p.on('pageerror',e=>errs.push(e.message));
await p.goto('file:///home/user/claude/tools/mapas/editor.html');await p.waitForTimeout(500);
// imagen sintética 20x12 casillas de 16px con colores parecidos a terrenos y ruido
const png = await p.evaluate(()=>{const c=document.createElement('canvas');c.width=320;c.height=192;const g=c.getContext('2d');
 const cols=[[130,180,90],[60,110,55],[80,140,210],[170,125,82]];
 for(let y=0;y<12;y++)for(let x=0;x<20;x++){const k=cols[(x>>2)%4];for(let i=0;i<40;i++){g.fillStyle=`rgb(${k[0]+Math.random()*20-10},${k[1]+Math.random()*20-10},${k[2]+Math.random()*20-10})`;g.fillRect(x*16+Math.random()*16,y*16+Math.random()*16,3,3);} g.globalCompositeOperation='destination-over';g.fillStyle=`rgb(${k})`;g.fillRect(x*16,y*16,16,16);g.globalCompositeOperation='source-over';}
 return c.toDataURL('image/png');});
require('fs').writeFileSync('/tmp/claude-0/-home-user-claude/239a793c-ff8c-5333-9eea-86ef9c21d83a/scratchpad/sint.png',Buffer.from(png.split(',')[1],'base64'));
await p.setInputFiles('#fImg','/tmp/claude-0/-home-user-claude/239a793c-ff8c-5333-9eea-86ef9c21d83a/scratchpad/sint.png');await p.waitForTimeout(600);
console.log(await p.$eval('#msgImg',e=>e.textContent));
await p.click('#exTxt');console.log((await p.$eval('#io',e=>e.value)).split('\n').slice(1,4).join('\n'));
console.log('errores',errs);await b.close();})();
